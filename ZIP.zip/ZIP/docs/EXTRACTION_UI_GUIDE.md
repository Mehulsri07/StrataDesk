# Strata Extraction UI Guide

## Visual Layout

### Main Application Structure

```
┌─────────────────────────────────────────────────────────────┐
│  StrataDesk                                    [- □ ×]       │ ← Title Bar
├─────────────────────────────────────────────────────────────┤
│  👤 User  │  📁 New  📤 Add  📦 Export  │  🌙 ⚙️ Sign Out  │ ← Nav Bar
├───────────┴─────────────────────────────────────────────────┤
│           │                                                   │
│  Sidebar  │  🗺️ Map View  │  🔍 Strata Extraction  │  📁 Files  │ ← Tabs
│           ├───────────────────────────────────────────────────┤
│  🔍       │                                                   │
│  Search   │                                                   │
│           │                                                   │
│  📁       │              Main Content Area                    │
│  Projects │                                                   │
│           │         (Map, Extraction, or Files)               │
│  📤       │                                                   │
│  Add Data │                                                   │
│           │                                                   │
│           │                                                   │
└───────────┴───────────────────────────────────────────────────┘
```

## Strata Extraction Tab Layout

### Step 1: Upload Files
```
┌─────────────────────────────────────────────────────────────┐
│  🔍 Strata Chart Extraction                      ❓ ⚙️      │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ① Upload Files                              📁     │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │                                                      │    │
│  │     ┌──────────────────────────────────────┐       │    │
│  │     │                                       │       │    │
│  │     │            📁                         │       │    │
│  │     │   Drop strata chart files here        │       │    │
│  │     │      or click to browse               │       │    │
│  │     │                                       │       │    │
│  │     │   [PDF] [Excel (.xlsx)] [Excel (.xls)]│       │    │
│  │     │                                       │       │    │
│  │     └──────────────────────────────────────┘       │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ② Configure Extraction                      ⚙️     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ③ Processing                                ⚙️     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ④ Review Results                            📊     │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### Step 2: Configure Extraction (Active)
```
┌─────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ② Configure Extraction                      ⚙️     │ ← Active
│  ├─────────────────────────────────────────────────────┤    │
│  │                                                      │    │
│  │  Confidence Threshold                               │    │
│  │  ┌────────────────────────────────────────────┐    │    │
│  │  │ Medium (50%) - Balanced accuracy      ▼   │    │    │
│  │  └────────────────────────────────────────────┘    │    │
│  │                                                      │    │
│  │  Depth Units                                        │    │
│  │  ┌────────────────────────────────────────────┐    │    │
│  │  │ Feet                                  ▼   │    │    │
│  │  └────────────────────────────────────────────┘    │    │
│  │                                                      │    │
│  │  Processing Options                                 │    │
│  │  ☑ Enable fallback processing                      │    │
│  │  ☑ Automatically open review interface             │    │
│  │                                                      │    │
│  │         ┌──────────────────────────┐               │    │
│  │         │  🔍 Start Extraction     │               │    │
│  │         └──────────────────────────┘               │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Step 3: Processing
```
┌─────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ③ Processing                                ⚙️     │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │                                                      │    │
│  │              ┌─────────────┐                        │    │
│  │              │             │                        │    │
│  │              │     45%     │  ← Circular Progress   │    │
│  │              │             │                        │    │
│  │              └─────────────┘                        │    │
│  │                                                      │    │
│  │          Processing sample.xlsx                     │    │
│  │            File 1 of 3                              │    │
│  │                                                      │    │
│  │  ┌──────────────────────────────────────────┐      │    │
│  │  │ 📖 Reading Files              ✅         │      │    │
│  │  └──────────────────────────────────────────┘      │    │
│  │  ┌──────────────────────────────────────────┐      │    │
│  │  │ 🔍 Parsing Data               ⚙️         │      │    │
│  │  └──────────────────────────────────────────┘      │    │
│  │  ┌──────────────────────────────────────────┐      │    │
│  │  │ ⚙️ Extracting Layers          ⏳         │      │    │
│  │  └──────────────────────────────────────────┘      │    │
│  │  ┌──────────────────────────────────────────┐      │    │
│  │  │ ✅ Validating                 ⏳         │      │    │
│  │  └──────────────────────────────────────────┘      │    │
│  │                                                      │    │
│  │              ┌────────────┐                         │    │
│  │              │   Cancel   │                         │    │
│  │              └────────────┘                         │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Step 4: Review Results
```
┌─────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────────┐    │
│  │  ④ Review Results                            📊     │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │                                                      │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐         │    │
│  │  │   📊     │  │   📁     │  │   🎯     │         │    │
│  │  │   12     │  │    3     │  │   85%    │         │    │
│  │  │ Layers   │  │  Files   │  │  Conf.   │         │    │
│  │  └──────────┘  └──────────┘  └──────────┘         │    │
│  │                                                      │    │
│  │  ┌────────────────────────────────────────────┐    │    │
│  │  │ Extracted Strata Layers          📤 ✏️    │    │    │
│  │  ├────────────────────────────────────────────┤    │    │
│  │  │ ▪ Topsoil                          [high]  │    │    │
│  │  │   0ft - 2ft (2ft thick)                    │    │    │
│  │  ├────────────────────────────────────────────┤    │    │
│  │  │ ▪ Clay                             [high]  │    │    │
│  │  │   2ft - 8ft (6ft thick)                    │    │    │
│  │  ├────────────────────────────────────────────┤    │    │
│  │  │ ▪ Sand                           [medium]  │    │    │
│  │  │   8ft - 15ft (7ft thick)                   │    │    │
│  │  ├────────────────────────────────────────────┤    │    │
│  │  │ ▪ Gravel                           [high]  │    │    │
│  │  │   15ft - 22ft (7ft thick)                  │    │    │
│  │  └────────────────────────────────────────────┘    │    │
│  │                                                      │    │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐           │    │
│  │  │👁️ Review │ │✅ Save   │ │🔄 Start  │           │    │
│  │  │  & Edit  │ │to Project│ │  Over    │           │    │
│  │  └──────────┘ └──────────┘ └──────────┘           │    │
│  │                                                      │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Sidebar Quick Extraction

### Before File Upload
```
┌─────────────────────────────┐
│  📤 Add Boring Data         │
├─────────────────────────────┤
│                             │
│  📁 Files                   │
│  ┌─────────────────────┐   │
│  │  📁                  │   │
│  │  Choose files or     │   │
│  │  drag & drop         │   │
│  └─────────────────────┘   │
│                             │
│  No files selected          │
│                             │
└─────────────────────────────┘
```

### After File Upload (Extraction Available)
```
┌─────────────────────────────┐
│  📤 Add Boring Data         │
├─────────────────────────────┤
│                             │
│  📁 Files                   │
│  sample.xlsx selected       │
│                             │
│  ┌─────────────────────┐   │
│  │ 🔍 Strata Chart     │   │
│  │ Extraction Available│   │
│  ├─────────────────────┤   │
│  │ ☑ Quick extract and │   │
│  │   add to current    │   │
│  │   boring            │   │
│  │                     │   │
│  │ ┌────────┐┌────────┐│   │
│  │ │🔍 Adv. ││⚡Quick ││   │
│  │ │Extract ││Extract ││   │
│  │ └────────┘└────────┘│   │
│  └─────────────────────┘   │
│                             │
└─────────────────────────────┘
```

## Color Coding

### Confidence Levels
- 🟢 **High** (70%+): Green background, reliable data
- 🟡 **Medium** (50-70%): Yellow background, review recommended
- 🔴 **Low** (<50%): Red background, manual verification needed

### Status Indicators
- ⏳ Pending
- ⚙️ Processing
- ✅ Complete
- ❌ Error

### Notifications
- 🔵 **Info**: Blue border (general information)
- 🟢 **Success**: Green border (operation successful)
- 🟡 **Warning**: Yellow border (attention needed)
- 🔴 **Error**: Red border (operation failed)

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl/Cmd + 1` | Switch to Map View |
| `Ctrl/Cmd + 2` | Switch to Strata Extraction |
| `Ctrl/Cmd + 3` | Switch to Files |
| `Ctrl/Cmd + U` | Upload files (when in extraction tab) |
| `Ctrl/Cmd + Enter` | Start extraction (when configured) |
| `Esc` | Cancel extraction / Close modal |

## Responsive Behavior

### Desktop (>1024px)
- Full sidebar visible
- All tabs visible
- Large upload zone
- Side-by-side result cards

### Tablet (768-1024px)
- Collapsible sidebar
- Scrollable tabs
- Medium upload zone
- Stacked result cards

### Mobile (<768px)
- Hidden sidebar (toggle button)
- Horizontal scrolling tabs
- Compact upload zone
- Single column layout

## Accessibility

- All interactive elements keyboard accessible
- ARIA labels for screen readers
- High contrast mode support
- Focus indicators visible
- Semantic HTML structure
- Alt text for icons